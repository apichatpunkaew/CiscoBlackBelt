#!/usr/bin/python

__author__ = 'learn_to_code'

# Written with pymongo-3.4

import sys
import pymongo
from partner_details_camp2 import SEED_DATA

### Create seed data

seed = SEED_DATA

### Standard URI format: mongodb://[dbuser:dbpassword@]host:port/dbname

uri = 'mongodb://'

###############################################################################
# main
###############################################################################

def addpoints():
    for entry in seed:
        total=0
        for key,value in entry["Meet_and_Greet"].items():
            total = total + value
        for key,value in entry["Camp1_Day1"].items():
            total = total + value
        for key,value in entry["Camp1_Day2"].items():
            total = total + value
        for key,value in entry["Camp1_Day3"].items():
            total = total + value
        for key,value in entry["Camp1_Day4"].items():
            total = total + value
        entry["Total Points"] = total

def dbaccess():
    addpoints()
    client = pymongo.MongoClient(uri)
    db = client.get_default_database()
    # First we'll add a few songs. Nothing is required to create the songs 
    # collection; it is created automatically when we insert.
    learn_to_code = db['PartnerProfile']
    # Note that the insert method can take either an array or a single dict.
    learn_to_code.insert_many(seed)
    # Then we need to give Boyz II Men credit for their contribution to
    # the hit "One Sweet Day".
    #query = {'song': 'One Sweet Day'}
    #songs.update(query, {'$set': {'artist': 'Mariah Carey ft. Boyz II Men'}})
    # Finally we run a query which returns all the hits that spent 10 or
    # more weeks at number 1.
    #cursor = songs.find({'weeksAtOne': {'$gte': 10}}).sort('decade', 1)
    client.close()


def show_leaderboard():
    client = pymongo.MongoClient(uri)
    db = client.get_default_database()
    learn_to_code = db['PartnerProfile']
    rank = 1

    cursor = learn_to_code.find({'Total Points' : {'$gte':0}}).sort('Total Points', pymongo.DESCENDING)
    result = "<br/> `'DevNet virtual Coding Camp (Oct-Nov FY18)' - APJ Leaderboard` <br/>"

    for doc in cursor:
        result = result + "<br/><br/> Rank #" + str(rank) + " `Team Name` - " + doc['Team Name'] + "<br/>`Partner Name` - " + doc['Partner Name'] + "<br/> `Location` - " + str(doc['Location']) + "<br/>" + "`Partner SE Names` - " + str(doc['Partner SE Names']) + "<br/>" + "`Total Points` - " + str(doc['Total Points'])
        rank +=1
    client.close()
    return result
