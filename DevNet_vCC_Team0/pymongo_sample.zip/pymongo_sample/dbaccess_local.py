#!/usr/bin/python

__author__ = 'learn_to_code'

# Written with pymongo-3.4

from partner_details_camp2 import SEED_DATA
import sys
import pymongo
import pprint



### Create seed data
seed = SEED_DATA
### Standard URI format: mongodb://[dbuser:dbpassword@]host:port/dbname

uri = 'mongodb://' #take from mongodb admin page in website

###############################################################################
# main
###############################################################################

def addpoints():
    for entry in seed:
        total=0
        for key,value in entry["Camp2_Day1"].items():
            total = total + value
        for key,value in entry["Camp2_Day2"].items():
            total = total + value
        entry["Total Points"] = total



def dbaccess():
    addpoints()
    client = pymongo.MongoClient(uri)
    db = client.get_default_database()
    leaderboard = db['PartnerProfile']
    leaderboard.drop()
    leaderboard = db['PartnerProfile']
    leaderboard.insert_many(seed)
    client.close()


dbaccess()
