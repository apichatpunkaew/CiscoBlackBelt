SEED_DATA = [
    {   'Team Name' : 'DevNet_vCC_Team1',
        'Total Points': 0,
        'Partner Name': "Airowire Networks and Comprinno Technologies",
        'Location': 'India',
        'Partner SE Names': 'Akshay Balaganur, Sushanth Mascarenhas, Apur Deshpande, Prasad Puranik',
        "Camp2_Day1": {'lab1':1,'lab2':1,"mission":3,"assign1":5,"assign2":5},
        "Camp2_Day2": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0}
        
    },
    {   'Team Name' : 'DevNet_vCC_Team2',
        'Total Points': 0,
        'Partner Name': "Dimension Data",
        'Location': 'India',
        'Partner SE Names': 'Venkatesh Bhat, Bardan Thapa, Avinash N, Sanish Joseph, Tanmay	Nandi, Mohammed Javid',
        "Camp2_Day1": {'lab1':1,'lab2':1,"mission":3,"assign1":5,"assign2":5},
        "Camp2_Day2": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0}
        
    },
    {   'Team Name' : 'DevNet_vCC_Team3',
        'Total Points': 0,
        'Partner Name': "Nipun Net Solutions",
        'Location': 'India',
        'Partner SE Names': 'Vamsi Krishna Grandhi, Sri Devi Prasad	Kurisetti, Sandip Narwade, Rakesh K, Ravi Chand	A, Srimannarayana Lakanavarapu, Sambasiva Rao	Venigalla',
        "Camp2_Day1": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0},
        "Camp2_Day2": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0}
        
    },
    {   'Team Name' : 'DevNet_vCC_Team4',
        'Total Points': 0,
        'Partner Name': "Comstor",
        'Location': 'New Zealand',
        'Partner SE Names': 'Roger Casanovas, Chris	Stewart',
        "Camp2_Day1": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0},
        "Camp2_Day2": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0}
        
    },
    {   'Team Name' : 'DevNet_vCC_Team5',
        'Total Points': 0,
        'Partner Name': "Datacom",
        'Location': 'New Zealand',
        'Partner SE Names': 'Mark George, Josh Farrelly, Mark Mc, Hussein O, Ivan V, David Ryland, Midhun Jackson, Ryan	Dick, Norman Victorio',
        "Camp2_Day1": {'lab1':1,'lab2':1,"mission":3,"assign1":5,"assign2":5},
        "Camp2_Day2": {'lab1':1,'lab2':1,"mission":3,"assign1":5,"assign2":5}
        
    },
    {   'Team Name' : 'DevNet_vCC_Team6',
        'Total Points': 0,
        'Partner Name': "Liquid IT",
        'Location': 'New Zealand',
        'Partner SE Names': 'Paul Richardson, Brendan Owen, Patric Balmer',
        "Camp2_Day1": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0},
        "Camp2_Day2": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0}
        
    },
    {   'Team Name' : 'DevNet_vCC_Team7',
        'Total Points': 0,
        'Partner Name': "Spark",
        'Location': 'New Zealand',
        'Partner SE Names': 'Luke Bonnici, Allan Teng, Bob Iswar, Dee Williamson, Angus	Williamson',
        "Camp2_Day1": {'lab1':1,'lab2':1,"mission":3,"assign1":5,"assign2":5},
        "Camp2_Day2": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0}
        
    },
    {   'Team Name' : 'DevNet_vCC_Team8',
        'Total Points': 0,
        'Partner Name': "SecureCom",
        'Location': 'New Zealand',
        'Partner SE Names': 'Jason	Kelly',
        "Camp2_Day1": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0},
        "Camp2_Day2": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0}
        
    },
    {   'Team Name' : 'DevNet_vCC_Team9',
        'Total Points': 0,
        'Partner Name': "NETQ",
        'Location': 'New Zealand',
        'Partner SE Names': 'Adrian	Soh, Pete Carnie, Marco	Huang, Jason Everard, Ravil	Gabaydullin, Jackson Kwok, Aaron Cottew',
        "Camp2_Day1": {'lab1':1,'lab2':1,"mission":3,"assign1":5,"assign2":5},
        "Camp2_Day2": {'lab1':1,'lab2':1,"mission":3,"assign1":5,"assign2":5}
        
    },
    {   'Team Name' : 'DevNet_vCC_Team10',
        'Total Points': 0,
        'Partner Name': "Locuz",
        'Location': 'India',
        'Partner SE Names': 'Ganesh	Kuncham',
        "Camp2_Day1": {'lab1':1,'lab2':1,"mission":3,"assign1":5,"assign2":5},
        "Camp2_Day2": {'lab1':1,'lab2':1,"mission":3,"assign1":5,"assign2":0}
        
    },
    {   'Team Name' : 'DevNet_vCC_Team11',
        'Total Points': 0,
        'Partner Name': "Wipro",
        'Location': 'India',
        'Partner SE Names': 'Abhishek Agarwal, Ajith Prasath N, Suneesh	Kannarambil, Nithin	P',
        "Camp2_Day1": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0},
        "Camp2_Day2": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0}
        
    },
    {   'Team Name' : 'DevNet_vCC_Team12',
        'Total Points': 0,
        'Partner Name': "Team Computers",
        'Location': 'India',
        'Partner SE Names': 'Mukul Bagre, Harsh Sharma',
        "Camp2_Day1": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0},
        "Camp2_Day2": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0}
        
    },
    {   'Team Name' : 'DevNet_vCC_Team13',
        'Total Points': 0,
        'Partner Name': "Dimension Data",
        'Location': 'Vietnam',
        'Partner SE Names': 'Dong Phan, Khoi Le',
        "Camp2_Day1": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0},
        "Camp2_Day2": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0}
        
    },
    {   'Team Name' : 'DevNet_vCC_Team14',
        'Total Points': 0,
        'Partner Name': "Advanced Information Technology",
        'Location': 'Thailand',
        'Partner SE Names': 'Supat Dulyakupt, Sittichai	Pornarunsthaporn',
        "Camp2_Day1": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0},
        "Camp2_Day2": {'lab1':0,'lab2':0,"mission":0,"assign1":0,"assign2":0}
        
    },
]




'''
{
    "Team Name": "Team Name",
    "Total Points": "Total Points",
    "Location": "Location",
    "Partner SE Names": "Partner SE Names",
    "contact emails": "contact emails"
}
'''

